# CSCI 5525 HW1

Daniel Chang, 5637953, chan1975@umn.edu

Requirements:
Python3, NumPy, pandas

How to run:
```bash
python3 hw1_q2.py
python3 hw1_q3.py
python3 hw1_q4.py
```

Note: the cross validation results are written to a csv file

Assumptions: I (deterministically) shuffled the data in the k-fold cross validation. I'm assuming this is ok (or preferred)
