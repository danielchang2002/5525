# CSCI 5525 HW1

Daniel Chang, 5637953, chan1975@umn.edu

Requirements:
Python3, NumPy, pandas

How to run:
```bash
python3 hw2_q2.py
python3 hw2_q4.py
```

Notes 
- The cross validation results are written to a csv file